import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Uint8List? _photoBytes;
  Position? _position;
  bool _loadingLocation = false;
  String? _error;

  Future<void> _pickImage(ImageSource source) async {
    try {
      final image = await ImagePicker().pickImage(source: source, imageQuality: 80);
      if (image == null) return;
      final bytes = await image.readAsBytes();
      if (!mounted) return;
      setState(() { _photoBytes = bytes; _error = null; });
    } catch (e) {
      if (mounted) setState(() => _error = 'Não foi possível obter a imagem: $e');
    }
  }

  Future<void> _getLocation() async {
    setState(() { _loadingLocation = true; _error = null; });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        throw Exception('Ative o serviço de localização.');
      }
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
        throw Exception('Permissão de localização não concedida.');
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
        timeLimit: const Duration(seconds: 15),
      );
      if (!mounted) return;
      setState(() => _position = pos);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loadingLocation = false);
    }
  }

  Future<void> _openMap() async {
    final pos = _position;
    if (pos == null) return;
    final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${pos.latitude},${pos.longitude}');
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) setState(() => _error = 'Não foi possível abrir o mapa.');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Perfil')),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Center(child: CircleAvatar(radius: 54, backgroundImage: _photoBytes == null ? null : MemoryImage(_photoBytes!),
        child: _photoBytes == null ? const Icon(Icons.person, size: 48) : null)),
      TextButton(onPressed: () => _pickImage(ImageSource.gallery), child: const Text('Escolher fotografia')),
      TextButton(onPressed: () => _pickImage(ImageSource.camera), child: const Text('Tirar fotografia')),
      FilledButton(onPressed: _loadingLocation ? null : _getLocation,
        child: Text(_loadingLocation ? 'A obter localização…' : 'Obter localização atual')),
      if (_position != null) Text('Lat: ${_position!.latitude}  Lon: ${_position!.longitude}'),
      if (_position != null) OutlinedButton(onPressed: _openMap, child: const Text('Abrir no mapa')),
      if (_error != null) Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
    ]),
  );
}
