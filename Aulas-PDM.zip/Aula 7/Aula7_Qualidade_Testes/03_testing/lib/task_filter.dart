class Task {
  final String title;
  final bool completed;
  const Task({required this.title, this.completed = false});
}

List<Task> pendingTasks(List<Task> tasks) =>
    tasks.where((task) => !task.completed).toList();
