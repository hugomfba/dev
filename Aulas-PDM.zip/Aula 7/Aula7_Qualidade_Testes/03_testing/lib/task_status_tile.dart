import 'package:flutter/material.dart';

class TaskStatusTile extends StatefulWidget {
  final String title;
  const TaskStatusTile({super.key, required this.title});
  @override State<TaskStatusTile> createState() => _TaskStatusTileState();
}

class _TaskStatusTileState extends State<TaskStatusTile> {
  bool _done = false;
  @override Widget build(BuildContext context) => CheckboxListTile(
    key: const Key('task-status'), value: _done,
    title: Text(widget.title),
    subtitle: Text(_done ? 'Concluída' : 'Pendente'),
    onChanged: (value) => setState(() => _done = value ?? false),
  );
}
