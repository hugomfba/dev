import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/task_status_tile.dart';

void main() {
  testWidgets('checkbox altera estado', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: TaskStatusTile(title: 'Preparar aula'),
    ));
    expect(find.text('Pendente'), findsOneWidget);
    await tester.tap(find.byKey(const Key('task-status')));
    await tester.pump();
    expect(find.text('Concluída'), findsOneWidget);
  });
}
