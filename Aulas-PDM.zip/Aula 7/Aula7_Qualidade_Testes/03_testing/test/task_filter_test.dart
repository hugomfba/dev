import 'package:flutter_test/flutter_test.dart';
import '../lib/task_filter.dart';

void main() {
  test('filtra tarefas concluídas', () {
    const tasks = [Task(title: 'A'), Task(title: 'B', completed: true)];
    expect(pendingTasks(tasks).map((t) => t.title), ['A']);
  });

  test('lista vazia continua vazia', () {
    expect(pendingTasks(const []), isEmpty);
  });
}
