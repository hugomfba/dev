# Aula 7 — Soluções dos desafios

Este pacote contém soluções de referência para os seis desafios incluídos na apresentação.

## Desafios
1. Refactoring: modelo Task e TaskCard reutilizável.
2. UX: FutureBuilder com estados loading/error/empty/success e refresh.
3. Testes: função pura, teste unitário, widget e widget test.
4. Performance: ListView.builder, keys estáveis, imagens dimensionadas.
5. Recursos do dispositivo: image_picker, geolocator e url_launcher.
6. Partilha: share_plus com SharePlus.instance.share.

## Dependências
No projeto de destino, adicionar quando necessário:

```bash
flutter pub add image_picker geolocator url_launcher share_plus
flutter pub add --dev flutter_test
```

Os exemplos devem ser copiados para a estrutura do projeto de destino. Os exemplos de teste importam ficheiros com caminhos relativos; ajustar o caminho se forem movidos para outra estrutura.

## Permissões
Android: acrescentar ACCESS_COARSE_LOCATION e ACCESS_FINE_LOCATION ao AndroidManifest.xml dentro de `<manifest>` e fora de `<application>`.

iOS: adicionar NSCameraUsageDescription e NSPhotoLibraryUsageDescription ao Info.plist.

Executar os exemplos em dispositivo ou emulador. O acesso à câmara/GPS depende do suporte da plataforma e da permissão concedida.

## Testes
```bash
flutter test
flutter analyze
```

## Nota
Os exemplos são módulos didáticos autónomos, não uma aplicação de produção completa. Confirmar versões compatíveis das dependências com o Flutter SDK instalado.
