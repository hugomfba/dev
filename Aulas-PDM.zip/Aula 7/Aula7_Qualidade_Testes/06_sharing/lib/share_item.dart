import 'package:share_plus/share_plus.dart';

Future<void> shareCatalogItem({
  required String title,
  required String description,
  required String url,
}) async {
  final text = '$title\n\n$description\n\n$url';
  await SharePlus.instance.share(ShareParams(title: title, text: text));
}
