import 'package:flutter/material.dart';

class CatalogEntry {
  final String id;
  final String title;
  final String imageUrl;
  const CatalogEntry({required this.id, required this.title, required this.imageUrl});
}

class CatalogList extends StatelessWidget {
  final List<CatalogEntry> entries;
  const CatalogList({super.key, required this.entries});

  @override
  Widget build(BuildContext context) => ListView.builder(
    itemCount: entries.length,
    itemBuilder: (context, index) {
      final entry = entries[index];
      return CatalogTile(key: ValueKey(entry.id), entry: entry);
    },
  );
}

class CatalogTile extends StatelessWidget {
  final CatalogEntry entry;
  const CatalogTile({super.key, required this.entry});

  @override
  Widget build(BuildContext context) => ListTile(
    leading: ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: Image.network(
        entry.imageUrl, width: 64, height: 64, fit: BoxFit.cover, cacheWidth: 160,
        errorBuilder: (_, __, ___) => const Icon(Icons.broken_image),
        loadingBuilder: (context, child, progress) => progress == null
          ? child
          : const SizedBox(width: 64, height: 64,
              child: Center(child: CircularProgressIndicator())),
      ),
    ),
    title: Text(entry.title, maxLines: 2, overflow: TextOverflow.ellipsis),
  );
}
