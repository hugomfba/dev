import 'package:flutter/material.dart';

Future<List<String>> fetchCatalog() async {
  await Future.delayed(const Duration(seconds: 1));
  return ['Gestão de despesas', 'Biblioteca', 'Viagens'];
}

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});
  @override State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  late Future<List<String>> _future;
  @override void initState() { super.initState(); _future = fetchCatalog(); }

  Future<void> _refresh() async {
    final next = fetchCatalog();
    setState(() => _future = next);
    await next;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Catálogo')),
    body: FutureBuilder<List<String>>(
      future: _future,
      builder: (context, snapshot) {
        late final Widget content;
        if (snapshot.connectionState == ConnectionState.waiting) {
          content = const Center(child: CircularProgressIndicator());
        } else if (snapshot.hasError) {
          content = Center(child: TextButton(
            onPressed: _refresh, child: const Text('Erro. Tentar novamente')));
        } else if ((snapshot.data ?? []).isEmpty) {
          content = const Center(child: Text('Ainda não existem itens.'));
        } else {
          content = ListView.builder(
            physics: const AlwaysScrollableScrollPhysics(),
            itemCount: snapshot.data!.length,
            itemBuilder: (_, i) => ListTile(title: Text(snapshot.data![i])),
          );
        }
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            children: [SizedBox(height: 420, child: content)],
          ),
        );
      },
    ),
  );
}
