class Task {
  final String id;
  final String title;
  final String subtitle;

  const Task({required this.id, required this.title, required this.subtitle});
}
