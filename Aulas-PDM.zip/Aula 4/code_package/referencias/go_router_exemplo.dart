// Exemplo didático de go_router para adaptar à aplicação.
// 1) Adiciona go_router às dependencies no pubspec.yaml.
// 2) Cria e usa o router através de MaterialApp.router.
// 3) Substitui TaskRouteScreen pelo ecrã real que carrega uma tarefa pelo id.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final GoRouter appRouter = GoRouter(
  routes: <RouteBase>[
    GoRoute(
      path: '/',
      builder: (context, state) => const PlaceholderHomeScreen(),
    ),
    GoRoute(
      path: '/tasks/:id',
      builder: (context, state) {
        final taskId = state.pathParameters['id']!;
        return TaskRouteScreen(taskId: taskId);
      },
    ),
  ],
);

class GoRouterExampleApp extends StatelessWidget {
  const GoRouterExampleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(routerConfig: appRouter);
  }
}

class PlaceholderHomeScreen extends StatelessWidget {
  const PlaceholderHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: FilledButton(
          onPressed: () => context.push('/tasks/demo-1'),
          child: const Text('Abrir tarefa de exemplo'),
        ),
      ),
    );
  }
}

class TaskRouteScreen extends StatelessWidget {
  const TaskRouteScreen({required this.taskId, super.key});

  final String taskId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalhe')),
      body: Center(child: Text('Carregar tarefa com id: $taskId')),
    );
  }
}
