# Aula 7 — Funcionalidades do dispositivo (Flutter)

Projeto pedagógico com soluções executáveis dos cinco desafios da apresentação **Programação de Dispositivos Móveis — Aula 7**.

## O que está incluído

1. **Desafio 1 — Plugins e permissões:** dependências, configuração Android/iOS e política de permissões. A página da app apresenta os passos; os snippets completos estão em `platform_config/`.
2. **Desafio 2 — Fotografia de perfil:** `image_picker`, seleção por galeria/câmara, leitura de bytes, `Image.memory`/`MemoryImage`, cancelamento e tratamento de erros.
3. **Desafio 3 — Localização e mapa:** `geolocator`, verificação do serviço, pedido de permissão, timeout, estados de carregamento/sucesso/erro e `url_launcher` para abrir Google Maps.
4. **Desafio 4 — API pública:** HTTP GET ao JSONPlaceholder, parsing JSON para `PhotoItem`, `FutureBuilder`, estados loading/error/empty/success e pull-to-refresh.
5. **Desafio 5 — API + favoritos SQLite:** tabela `favorites`, `FavoritesRepository` com insert/query/delete, `ChangeNotifier` + Provider, explorar resultados remotos e consultar favoritos persistentes.

A API utilizada é `https://jsonplaceholder.typicode.com/photos?_limit=20`.

## Requisitos

- Flutter com Dart **3.7.0 ou superior**.
- Visual Studio Code com extensões Flutter e Dart.
- Google Chrome para a execução Web.
- Android Studio + Android SDK + emulador, se pretender executar em Android.

As versões das dependências estão declaradas no `pubspec.yaml`. O Pub resolve as versões compatíveis com o Dart SDK instalado.

## Preparação no Windows

### Opção A — Chrome (inclui preparação SQLite Web)

1. Extrair o ZIP.
2. Abrir a pasta `Aula7_Funcionalidades_Dispositivo` no VS Code. É importante abrir a pasta que contém `pubspec.yaml`.
3. Abrir **Terminal → New Terminal**.
4. Executar:

```powershell
.\setup_windows.bat
```

5. No fim, executar:

```powershell
flutter run -d chrome
```

Se preferir executar os passos manualmente:

```powershell
flutter create --platforms=android,ios,web .
flutter pub get
dart run sqflite_common_ffi_web:setup
flutter run -d chrome
```

O comando de setup Web cria `web/sqlite3.wasm` e `web/sqflite_sw.js`, necessários à implementação SQLite no browser.

### Opção B — Android (recomendado para a UC)

1. Abrir o Android Studio e iniciar um emulador, ou ligar um dispositivo Android com depuração USB.
2. Executar `setup_android_only.bat` ou, manualmente:

```powershell
flutter create --platforms=android,ios .
flutter pub get
```

3. Aplicar as permissões indicadas na secção **Configuração por plataforma**.
4. Confirmar o dispositivo:

```powershell
flutter devices
```

5. Executar:

```powershell
flutter run -d ID_DO_EMULADOR
```

## Configuração por plataforma

### Android

Abrir `android/app/src/main/AndroidManifest.xml` e adicionar, como filhos diretos de `<manifest>` e antes de `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

O `image_picker` utiliza os intents/Photo Picker do sistema Android e não necessita das antigas permissões de armazenamento para este fluxo.

O pacote `image_picker` atual indica Android SDK 24 ou superior. Confirma `minSdk` no ficheiro Gradle do módulo `app`; se estiver abaixo de 24, define-o como 24. O `geolocator` documenta `compileSdk` 35 ou superior.

### iOS

Em `ios/Runner/Info.plist`, dentro de `<dict>`, adicionar as entradas que estão em `platform_config/Info.plist-snippet.xml`:

- `NSCameraUsageDescription`
- `NSPhotoLibraryUsageDescription`
- `NSLocationWhenInUseUsageDescription`

### Chrome / Web

- A geolocalização do navegador requer contexto seguro: `localhost` ou HTTPS.
- O navegador pede autorização para localização. Se for recusada, permitir o acesso nas definições do site.
- A seleção de imagem abre o seletor de ficheiros do browser. O modo câmara pode variar com o browser e o dispositivo.
- O SQLite Web usa `sqflite_common_ffi_web`, que é experimental. A persistência é feita em IndexedDB.
- Mantém a mesma porta `localhost` entre execuções para veres o mesmo armazenamento IndexedDB. `localhost:5000` e `localhost:5001` são origens diferentes.

## Estrutura do código

```text
lib/
├── main.dart
├── data/
│   └── app_database.dart
├── models/
│   └── photo_item.dart
├── repositories/
│   └── favorites_repository.dart
├── services/
│   ├── location_service.dart
│   └── photo_api.dart
├── state/
│   └── favorites_controller.dart
└── screens/
    ├── home_screen.dart
    ├── challenge1_setup_screen.dart
    ├── profile_photo_screen.dart
    ├── location_screen.dart
    ├── photo_api_screen.dart
    └── favorites_screen.dart
```

## Como testar os cinco desafios

### Desafio 1 — Plugins e permissões

1. Abrir o primeiro cartão no ecrã inicial.
2. Confirmar os packages no `pubspec.yaml`.
3. Aplicar as permissões Android ou as descrições iOS.
4. Verificar que a aplicação continua utilizável se a permissão de localização for recusada.

### Desafio 2 — Fotografia de perfil

1. Abrir **Fotografia de perfil**.
2. Selecionar **Galeria** ou **Câmara**.
3. Escolher/tirar uma fotografia.
4. Confirmar que aparece no avatar.
5. Abrir novamente o seletor e cancelar: a fotografia anterior deve manter-se.

A solução mantém os bytes em memória para o exercício. Não persiste a fotografia após encerrar a aplicação; essa evolução exige copiar o ficheiro para uma pasta persistente e guardar o caminho.

### Desafio 3 — Localização e mapa

1. Abrir **Localização e mapa**.
2. Escolher **Obter localização atual**.
3. Autorizar a localização no sistema/navegador.
4. Confirmar latitude, longitude e precisão aproximada.
5. Escolher **Abrir no mapa**.

Num emulador Android, pode ser necessário definir uma localização nas opções do emulador. No Chrome, autorizar a localização para `localhost`.

### Desafio 4 — API pública

1. Abrir **Consumir uma API**.
2. Observar o indicador de carregamento.
3. Confirmar a lista de fotografias remota.
4. Puxar a lista para baixo ou carregar no ícone de atualizar.
5. Desligar a Internet e voltar a atualizar para observar o estado de erro.

### Desafio 5 — Favoritos persistentes

1. Abrir **API + favoritos SQLite**.
2. No separador **Explorar**, selecionar o coração de uma fotografia.
3. Abrir **Favoritos** e confirmar que aparece na lista local.
4. Fechar e voltar a abrir a aplicação.
5. Confirmar que o favorito permanece disponível.
6. Remover o favorito e confirmar que desaparece.

## Comandos úteis

```powershell
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter devices
flutter run -d chrome
flutter run -d ID_DO_EMULADOR
```

## Limitações conhecidas

- Não foi possível executar `flutter pub get`, `flutter analyze` ou `flutter run` no ambiente de criação deste ZIP, pelo que a compilação final tem de ser confirmada no computador do aluno/docente.
- A implementação SQLite para Web é experimental. Para avaliação de uma aplicação móvel, recomenda-se testar a persistência em Android/iOS com `sqflite` nativo.
- O exemplo usa JSONPlaceholder como API didática. Os registos são dados de demonstração; não se trata de um serviço de fotografias pessoais.
- A fotografia de perfil é mantida em memória. O exercício avalia a integração com galeria/câmara e não o armazenamento permanente da imagem.
