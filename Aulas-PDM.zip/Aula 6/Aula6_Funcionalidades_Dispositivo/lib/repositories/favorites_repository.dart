import 'package:sqflite/sqflite.dart';

import '../models/photo_item.dart';

class FavoritesRepository {
  FavoritesRepository(this._database);

  final Database _database;

  Future<void> add(PhotoItem item) async {
    await _database.insert(
      'favorites',
      item.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<PhotoItem>> getAll() async {
    final rows = await _database.query('favorites', orderBy: 'title COLLATE NOCASE');
    return rows
        .map((row) => PhotoItem.fromMap(Map<String, Object?>.from(row)))
        .toList(growable: false);
  }

  Future<bool> contains(int id) async {
    final rows = await _database.query(
      'favorites',
      columns: ['id'],
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    return rows.isNotEmpty;
  }

  Future<void> remove(int id) async {
    await _database.delete(
      'favorites',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
