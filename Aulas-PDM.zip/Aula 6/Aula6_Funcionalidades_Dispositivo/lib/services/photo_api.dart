import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/photo_item.dart';

class PhotoApi {
  PhotoApi({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;
  static final Uri _endpoint = Uri.https(
    'jsonplaceholder.typicode.com',
    '/photos',
    {'_limit': '20'},
  );

  Future<List<PhotoItem>> fetchPhotos() async {
    late http.Response response;
    try {
      response = await _client
          .get(_endpoint)
          .timeout(const Duration(seconds: 12));
    } on TimeoutException {
      throw Exception('O servidor demorou demasiado tempo a responder.');
    } catch (error) {
      throw Exception('Falha de comunicação com a API. Verifica a Internet. ($error)');
    }

    if (response.statusCode != 200) {
      throw Exception('A API respondeu com HTTP ${response.statusCode}.');
    }

    final dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw Exception('A resposta do servidor não contém JSON válido.');
    }

    if (decoded is! List<dynamic>) {
      throw const FormatException('A resposta da API não é uma lista.');
    }

    return decoded
        .map((item) => PhotoItem.fromJson(item as Map<String, dynamic>))
        .toList(growable: false);
  }

  void dispose() => _client.close();
}
