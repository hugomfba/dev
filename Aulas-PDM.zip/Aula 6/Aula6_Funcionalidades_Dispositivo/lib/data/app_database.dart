import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    final String databasePath;
    if (kIsWeb) {
      // O nome é relativo à origem/porta do site no IndexedDB.
      databasePath = 'aula7_device_features.db';
    } else {
      final directory = await getDatabasesPath();
      databasePath = path.join(directory, 'aula7_device_features.db');
    }

    _database = await openDatabase(
      databasePath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE favorites (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            thumbnailUrl TEXT NOT NULL
          )
        ''');
      },
    );

    return _database!;
  }
}
