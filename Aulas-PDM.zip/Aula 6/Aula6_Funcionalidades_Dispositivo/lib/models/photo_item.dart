class PhotoItem {
  final int id;
  final String title;
  final String thumbnailUrl;

  const PhotoItem({
    required this.id,
    required this.title,
    required this.thumbnailUrl,
  });

  factory PhotoItem.fromJson(Map<String, dynamic> json) {
    final id = json['id'];
    final title = json['title'];
    final thumbnailUrl = json['thumbnailUrl'];

    if (id is! int || title is! String || thumbnailUrl is! String) {
      throw const FormatException('Formato de fotografia inválido recebido da API.');
    }

    return PhotoItem(
      id: id,
      title: title,
      thumbnailUrl: thumbnailUrl,
    );
  }

  factory PhotoItem.fromMap(Map<String, Object?> map) {
    return PhotoItem(
      id: map['id'] as int,
      title: map['title'] as String,
      thumbnailUrl: map['thumbnailUrl'] as String,
    );
  }

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'thumbnailUrl': thumbnailUrl,
      };
}
