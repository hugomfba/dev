import 'package:flutter/material.dart';

class Challenge1SetupScreen extends StatelessWidget {
  const Challenge1SetupScreen({super.key});

  static const _packages = [
    ('image_picker', 'Galeria e captura de fotografia.'),
    ('geolocator', 'Serviço de localização e permissões.'),
    ('url_launcher', 'Abrir uma localização numa aplicação de mapas.'),
    ('http', 'Pedidos HTTP para serviços Web.'),
    ('sqflite + path', 'Base de dados SQLite e construção de caminhos.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Desafio 1 · Plugins e permissões')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Dependências',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          const Text('Executar na raiz do projeto:'),
          const SizedBox(height: 8),
          const _CodeCard(
            code: 'flutter pub add image_picker\n'
                'flutter pub add geolocator\n'
                'flutter pub add url_launcher\n'
                'flutter pub add http\n'
                'flutter pub add sqflite path',
          ),
          const SizedBox(height: 16),
          for (final package in _packages)
            Card(
              child: ListTile(
                leading: const Icon(Icons.extension_outlined),
                title: Text(package.$1),
                subtitle: Text(package.$2),
              ),
            ),
          const SizedBox(height: 16),
          Text('Android · AndroidManifest.xml',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          const Text(
            'Adicionar como filhos diretos de <manifest>, antes de <application>:',
          ),
          const SizedBox(height: 8),
          const _CodeCard(
            code: '<uses-permission android:name="android.permission.INTERNET" />\n'
                '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n'
                '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
          ),
          const SizedBox(height: 16),
          Text('iOS · Info.plist',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          const Text('Adicionar dentro de <dict>:'),
          const SizedBox(height: 8),
          const _CodeCard(
            code: '<key>NSCameraUsageDescription</key>\n'
                '<string>Permitir tirar uma fotografia de perfil.</string>\n'
                '<key>NSPhotoLibraryUsageDescription</key>\n'
                '<string>Permitir escolher uma fotografia de perfil.</string>\n'
                '<key>NSLocationWhenInUseUsageDescription</key>\n'
                '<string>Permitir apresentar a localização atual.</string>',
          ),
          const SizedBox(height: 16),
          Card(
            color: Theme.of(context).colorScheme.tertiaryContainer,
            child: const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Regras de permissões\n\n'
                '• Pedir a permissão apenas quando a funcionalidade é utilizada.\n'
                '• Explicar ao utilizador para que serve.\n'
                '• Se for recusada, não bloquear o resto da aplicação.\n'
                '• Permitir tentar novamente quando o sistema o permitir.\n'
                '• Não guardar nem partilhar dados sem necessidade.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Para o image_picker, o Android moderno utiliza o seletor do sistema '
            'e não precisa de permissões antigas de armazenamento. A câmara e '
            'a galeria são tratadas pelo plugin. No iOS, as descrições no '
            'Info.plist são necessárias.',
          ),
        ],
      ),
    );
  }
}

class _CodeCard extends StatelessWidget {
  const _CodeCard({required this.code});

  final String code;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: SelectableText(
          code,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
        ),
      ),
    );
  }
}
