import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ProfilePhotoScreen extends StatefulWidget {
  const ProfilePhotoScreen({super.key});

  @override
  State<ProfilePhotoScreen> createState() => _ProfilePhotoScreenState();
}

class _ProfilePhotoScreenState extends State<ProfilePhotoScreen> {
  final ImagePicker _picker = ImagePicker();
  Uint8List? _photoBytes;
  bool _loading = false;
  String? _error;

  Future<void> _pick(ImageSource source) async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final XFile? selected = await _picker.pickImage(
        source: source,
        imageQuality: 80,
        maxWidth: 1600,
      );

      // O utilizador cancelou: manter a fotografia anterior.
      if (selected == null) return;

      final bytes = await selected.readAsBytes();
      if (!mounted) return;

      setState(() {
        _photoBytes = bytes;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Não foi possível obter a imagem. $error';
      });
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _showSourceOptions() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Escolher da galeria'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_outlined),
              title: const Text('Tirar fotografia'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
          ],
        ),
      ),
    );

    if (source != null && mounted) {
      await _pick(source);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasPhoto = _photoBytes != null;

    return Scaffold(
      appBar: AppBar(title: const Text('Desafio 2 · Fotografia de perfil')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 76,
                  backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  backgroundImage: hasPhoto ? MemoryImage(_photoBytes!) : null,
                  child: hasPhoto
                      ? null
                      : const Icon(Icons.person, size: 72),
                ),
                const SizedBox(height: 20),
                Text(
                  hasPhoto ? 'Fotografia selecionada' : 'Sem fotografia de perfil',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 16),
                if (_loading) const CircularProgressIndicator(),
                if (_error != null) ...[
                  Text(
                    _error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Theme.of(context).colorScheme.error),
                  ),
                  const SizedBox(height: 12),
                ],
                FilledButton.icon(
                  onPressed: _loading ? null : _showSourceOptions,
                  icon: const Icon(Icons.add_a_photo_outlined),
                  label: const Text('Alterar fotografia'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _loading || !hasPhoto
                      ? null
                      : () => setState(() => _photoBytes = null),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Remover fotografia'),
                ),
                const SizedBox(height: 24),
                const Text(
                  'A imagem é mantida em memória enquanto este ecrã está ativo. '
                  'Para persistir a fotografia após fechar a aplicação, é '
                  'necessário copiar o ficheiro para armazenamento da app e '
                  'guardar o caminho numa base de dados ou preferências.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
