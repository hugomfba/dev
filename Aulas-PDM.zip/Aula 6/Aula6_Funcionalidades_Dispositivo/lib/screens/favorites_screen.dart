import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/photo_item.dart';
import '../state/favorites_controller.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  int _selectedIndex = 0;

  Future<void> _toggleFavorite(PhotoItem item) async {
    try {
      await context.read<FavoritesController>().toggleFavorite(item);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível atualizar o favorito: $error')),
      );
    }
  }

  Future<void> _refresh() async {
    final controller = context.read<FavoritesController>();
    if (_selectedIndex == 0) {
      await controller.refreshPhotos();
    } else {
      await controller.refreshFavorites();
    }
  }

  Widget _scrollState(Widget child) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [SizedBox(height: 420, child: Center(child: child))],
      ),
    );
  }

  Widget _photoList(
    List<PhotoItem> items, {
    required FavoritesController controller,
  }) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(12),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (context, index) {
          final item = items[index];
          final favorite = controller.isFavorite(item.id);
          return Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  item.thumbnailUrl,
                  width: 58,
                  height: 58,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 58,
                    height: 58,
                    child: Icon(Icons.broken_image_outlined),
                  ),
                ),
              ),
              title: Text(
                item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text('ID remoto: ${item.id}'),
              trailing: IconButton(
                tooltip: favorite ? 'Remover favorito' : 'Guardar favorito',
                onPressed: () => _toggleFavorite(item),
                icon: Icon(
                  favorite ? Icons.favorite : Icons.favorite_border,
                  color: favorite ? Colors.red : null,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<FavoritesController>();
    final isExplore = _selectedIndex == 0;

    Widget content;
    if (isExplore && controller.loadingPhotos) {
      content = _scrollState(const CircularProgressIndicator());
    } else if (isExplore && controller.photosError != null) {
      content = _scrollState(
        Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.cloud_off_outlined, size: 48),
              const SizedBox(height: 12),
              const Text('Erro ao carregar a API.'),
              const SizedBox(height: 8),
              Text(controller.photosError!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: controller.refreshPhotos,
                child: const Text('Tentar novamente'),
              ),
            ],
          ),
        ),
      );
    } else if (isExplore && controller.photos.isEmpty) {
      content = _scrollState(const Text('A API não devolveu fotografias.'));
    } else if (!isExplore && controller.loadingFavorites) {
      content = _scrollState(const CircularProgressIndicator());
    } else if (!isExplore && controller.favoritesError != null) {
      content = _scrollState(Text(controller.favoritesError!));
    } else if (!isExplore && controller.savedFavorites.isEmpty) {
      content = _scrollState(
        const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.favorite_border, size: 48),
            SizedBox(height: 12),
            Text('Ainda não guardaste favoritos.'),
            Text('Vai a Explorar e seleciona o coração.'),
          ],
        ),
      );
    } else {
      content = _photoList(
        isExplore ? controller.photos : controller.savedFavorites,
        controller: controller,
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Desafio 5 · API + SQLite'),
        actions: [
          IconButton(
            tooltip: 'Atualizar',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 850),
          child: content,
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() => _selectedIndex = index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.explore_outlined),
            selectedIcon: Icon(Icons.explore),
            label: 'Explorar',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'Favoritos',
          ),
        ],
      ),
    );
  }
}
