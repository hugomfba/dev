import 'package:flutter/material.dart';

import '../models/photo_item.dart';
import '../services/photo_api.dart';

class PhotoApiScreen extends StatefulWidget {
  const PhotoApiScreen({super.key});

  @override
  State<PhotoApiScreen> createState() => _PhotoApiScreenState();
}

class _PhotoApiScreenState extends State<PhotoApiScreen> {
  final PhotoApi _api = PhotoApi();
  late Future<List<PhotoItem>> _future;

  @override
  void initState() {
    super.initState();
    _future = _api.fetchPhotos();
  }

  @override
  void dispose() {
    _api.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final newFuture = _api.fetchPhotos();
    setState(() => _future = newFuture);
    try {
      await newFuture;
    } catch (_) {
      // O FutureBuilder apresenta o erro. Não deixar a exceção escapar
      // do callback de RefreshIndicator.
    }
  }

  Widget _stateList({required Widget child}) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: 420, child: Center(child: child)),
        ],
      ),
    );
  }

  Widget _photoList(List<PhotoItem> photos) {
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(12),
        itemCount: photos.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (context, index) {
          final photo = photos[index];
          return Card(
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  photo.thumbnailUrl,
                  width: 58,
                  height: 58,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 58,
                    height: 58,
                    child: Icon(Icons.broken_image_outlined),
                  ),
                ),
              ),
              title: Text(
                photo.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text('ID: ${photo.id}'),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Desafio 4 · API pública'),
        actions: [
          IconButton(
            tooltip: 'Atualizar',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: FutureBuilder<List<PhotoItem>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return _stateList(
              child: const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('A carregar fotografias…'),
                ],
              ),
            );
          }

          if (snapshot.hasError) {
            return _stateList(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.cloud_off_outlined, size: 48),
                    const SizedBox(height: 12),
                    const Text('Não foi possível carregar os dados.'),
                    const SizedBox(height: 8),
                    Text('${snapshot.error}', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _refresh,
                      icon: const Icon(Icons.refresh),
                      label: const Text('Tentar novamente'),
                    ),
                  ],
                ),
              ),
            );
          }

          final photos = snapshot.data ?? const <PhotoItem>[];
          if (photos.isEmpty) {
            return _stateList(
              child: const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.photo_library_outlined, size: 48),
                  SizedBox(height: 12),
                  Text('A API não devolveu resultados.'),
                  Text('Puxa o ecrã para baixo para atualizar.'),
                ],
              ),
            );
          }

          return _photoList(photos);
        },
      ),
    );
  }
}
