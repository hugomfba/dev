import 'package:flutter/material.dart';

import 'challenge1_setup_screen.dart';
import 'favorites_screen.dart';
import 'location_screen.dart';
import 'photo_api_screen.dart';
import 'profile_photo_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    final challenges = <_ChallengeEntry>[
      _ChallengeEntry(
        number: '01',
        title: 'Plugins e permissões',
        description: 'Dependências e configuração Android/iOS.',
        icon: Icons.tune,
        onTap: () => _open(context, const Challenge1SetupScreen()),
      ),
      _ChallengeEntry(
        number: '02',
        title: 'Fotografia de perfil',
        description: 'Escolher uma imagem da galeria ou tirar uma fotografia.',
        icon: Icons.add_a_photo_outlined,
        onTap: () => _open(context, const ProfilePhotoScreen()),
      ),
      _ChallengeEntry(
        number: '03',
        title: 'Localização e mapa',
        description: 'Pedir autorização, obter coordenadas e abrir o mapa.',
        icon: Icons.location_on_outlined,
        onTap: () => _open(context, const LocationScreen()),
      ),
      _ChallengeEntry(
        number: '04',
        title: 'Consumir uma API',
        description: 'GET, JSON, FutureBuilder e pull-to-refresh.',
        icon: Icons.cloud_download_outlined,
        onTap: () => _open(context, const PhotoApiScreen()),
      ),
      _ChallengeEntry(
        number: '05',
        title: 'API + favoritos SQLite',
        description: 'Guardar e consultar favoritos localmente.',
        icon: Icons.favorite_outline,
        onTap: () => _open(context, const FavoritesScreen()),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Aula 7 · Funcionalidades do dispositivo'),
        actions: [
          IconButton(
            tooltip: 'Sobre o projeto',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'Aula 7 — Flutter',
              applicationVersion: '1.0.0',
              children: const [
                Text('Exemplos pedagógicos dos cinco desafios da aula.'),
              ],
            ),
            icon: const Icon(Icons.info_outline),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 850),
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Integração com recursos reais',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Explora fotografia, localização, comunicação HTTP e '
                        'persistência local. Cada cartão corresponde a um desafio '
                        'da apresentação da Aula 7.',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              for (final challenge in challenges)
                Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: CircleAvatar(
                      child: Text(challenge.number),
                    ),
                    title: Text(challenge.title),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Text(challenge.description),
                    ),
                    trailing: Icon(challenge.icon),
                    onTap: challenge.onTap,
                  ),
                ),
              const SizedBox(height: 8),
              const Text(
                'Nota: para testar câmara e GPS, utiliza preferencialmente um '
                'dispositivo físico ou um emulador com essas funcionalidades. '
                'No Chrome, a localização depende da autorização do navegador.',
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChallengeEntry {
  const _ChallengeEntry({
    required this.number,
    required this.title,
    required this.description,
    required this.icon,
    required this.onTap,
  });

  final String number;
  final String title;
  final String description;
  final IconData icon;
  final VoidCallback onTap;
}
