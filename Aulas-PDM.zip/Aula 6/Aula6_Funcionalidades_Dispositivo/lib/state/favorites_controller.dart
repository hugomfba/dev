import 'package:flutter/foundation.dart';

import '../models/photo_item.dart';
import '../repositories/favorites_repository.dart';
import '../services/photo_api.dart';

class FavoritesController extends ChangeNotifier {
  FavoritesController({
    required PhotoApi api,
    required FavoritesRepository repository,
  })  : _api = api,
        _repository = repository;

  final PhotoApi _api;
  final FavoritesRepository _repository;

  List<PhotoItem> photos = [];
  List<PhotoItem> savedFavorites = [];
  bool loadingPhotos = false;
  bool loadingFavorites = false;
  String? photosError;
  String? favoritesError;

  Future<void> initialize() async {
    await Future.wait([refreshPhotos(), refreshFavorites()]);
  }

  Future<void> refreshPhotos() async {
    loadingPhotos = true;
    photosError = null;
    notifyListeners();

    try {
      photos = await _api.fetchPhotos();
    } catch (error) {
      photosError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      loadingPhotos = false;
      notifyListeners();
    }
  }

  Future<void> refreshFavorites() async {
    loadingFavorites = true;
    favoritesError = null;
    notifyListeners();

    try {
      savedFavorites = await _repository.getAll();
    } catch (error) {
      favoritesError = error.toString();
    } finally {
      loadingFavorites = false;
      notifyListeners();
    }
  }

  bool isFavorite(int id) => savedFavorites.any((item) => item.id == id);

  Future<void> toggleFavorite(PhotoItem item) async {
    try {
      if (await _repository.contains(item.id)) {
        await _repository.remove(item.id);
      } else {
        await _repository.add(item);
      }
      await refreshFavorites();
    } catch (error) {
      favoritesError = 'Não foi possível atualizar os favoritos: $error';
      notifyListeners();
      rethrow;
    }
  }

  Future<void> removeFavorite(int id) async {
    await _repository.remove(id);
    await refreshFavorites();
  }

  @override
  void dispose() {
    _api.dispose();
    super.dispose();
  }
}
