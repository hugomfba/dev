import 'package:flutter_test/flutter_test.dart';
import 'package:aula7_funcionalidades_dispositivo/models/photo_item.dart';

void main() {
  test('PhotoItem converte JSON para modelo', () {
    final item = PhotoItem.fromJson({
      'id': 7,
      'title': 'Fotografia de exemplo',
      'thumbnailUrl': 'https://example.com/thumb.jpg',
    });

    expect(item.id, 7);
    expect(item.title, 'Fotografia de exemplo');
    expect(item.thumbnailUrl, 'https://example.com/thumb.jpg');
  });

  test('PhotoItem converte modelo para mapa e de volta', () {
    const original = PhotoItem(
      id: 12,
      title: 'Favorito',
      thumbnailUrl: 'https://example.com/12.jpg',
    );

    final restored = PhotoItem.fromMap(original.toMap());

    expect(restored.id, original.id);
    expect(restored.title, original.title);
    expect(restored.thumbnailUrl, original.thumbnailUrl);
  });

  test('PhotoItem rejeita dados JSON com tipos inválidos', () {
    expect(
      () => PhotoItem.fromJson({
        'id': 'não é número',
        'title': 'Inválido',
        'thumbnailUrl': 'https://example.com/x.jpg',
      }),
      throwsFormatException,
    );
  });
}
