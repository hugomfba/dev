@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo Aula 7 - Preparacao Android (Windows)
echo ================================================

where flutter >nul 2>nul
if errorlevel 1 (
  echo ERRO: Flutter nao foi encontrado no PATH.
  pause
  exit /b 1
)

if not exist android\ (
  flutter create --platforms=android,ios .
  if errorlevel 1 goto :error
)

flutter pub get
if errorlevel 1 goto :error

echo.
echo Preparacao concluida. Confirma as permissoes no AndroidManifest.xml.
echo Executa: flutter devices
 echo Depois: flutter run -d ID_DO_EMULADOR
pause
exit /b 0

:error
echo Ocorreu um erro durante a preparacao.
pause
exit /b 1
