@echo off
setlocal
cd /d "%~dp0"

echo ================================================
echo Aula 6 - Preparacao do projeto Flutter (Windows)
echo ================================================

where flutter >nul 2>nul
if errorlevel 1 (
  echo ERRO: Flutter nao foi encontrado no PATH.
  echo Instala o Flutter SDK e reinicia o VS Code.
  pause
  exit /b 1
)

flutter --version
if errorlevel 1 goto :error

if not exist android\ (
  echo A gerar plataforma Android...
  flutter create --platforms=android,ios,web .
  if errorlevel 1 goto :error
) else if not exist web\ (
  echo A adicionar plataforma Web...
  flutter create --platforms=web .
  if errorlevel 1 goto :error
)

echo A instalar dependencias Flutter...
flutter pub get
if errorlevel 1 goto :error

echo A preparar SQLite para Flutter Web...
dart run sqflite_common_ffi_web:setup
if errorlevel 1 goto :error

echo.
echo Preparacao concluida.
echo Para executar no Chrome: flutter run -d chrome
echo Para Android: flutter devices e flutter run -d ID_DO_EMULADOR
echo.
pause
exit /b 0

:error
echo.
echo A preparacao terminou com erro. Consulta a mensagem acima.
pause
exit /b 1
