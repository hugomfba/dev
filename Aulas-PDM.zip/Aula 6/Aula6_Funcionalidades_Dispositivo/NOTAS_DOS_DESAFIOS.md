# Resolução pedagógica dos cinco desafios — Aula 6

## Desafio 1 — Escolher o plugin e definir as permissões

**Plugins escolhidos**
- `image_picker`: usa a interface nativa para escolher da galeria ou tirar uma fotografia.
- `geolocator`: verifica o serviço de localização, pede autorização e devolve coordenadas.
- `url_launcher`: abre o URL do mapa no browser/aplicação apropriada.

**Dependências**
`image_picker`, `geolocator`, `url_launcher`, `http`, `sqflite`, `path` e `sqflite_common_ffi_web` estão declarados em `pubspec.yaml`.

**Configuração**
- Android: Internet, `ACCESS_COARSE_LOCATION` e `ACCESS_FINE_LOCATION` em `AndroidManifest.xml`.
- iOS: descrições de câmara, biblioteca de fotografias e localização em `Info.plist`.
- Android: o `image_picker` atual não necessita de permissões antigas de armazenamento para o fluxo normal.

**Recusa**
A aplicação não deve encerrar nem ficar bloqueada. O ecrã de localização apresenta uma mensagem, permite continuar a utilizar as outras funções e informa quando a permissão tem de ser reativada nas definições.

Código: `lib/screens/challenge1_setup_screen.dart`, `platform_config/` e configuração geral do `pubspec.yaml`.

## Desafio 2 — Implementar a fotografia de perfil

**Fluxo implementado**
1. O utilizador escolhe Galeria ou Câmara num bottom sheet.
2. `ImagePicker.pickImage` devolve `XFile?`.
3. Se for `null`, o utilizador cancelou; o estado anterior não é alterado.
4. Se existir ficheiro, `readAsBytes()` obtém os bytes.
5. `setState` atualiza `_photoBytes`.
6. `CircleAvatar` apresenta `MemoryImage(_photoBytes!)`.
7. Exceções são capturadas e apresentadas sem apagar a fotografia anterior.

Código completo: `lib/screens/profile_photo_screen.dart`.

## Desafio 3 — Localização atual e botão Abrir no mapa

**Serviço**
`LocationService.currentPosition()` verifica o serviço, verifica/pede a permissão e chama `Geolocator.getCurrentPosition` com precisão alta e limite de 20 segundos.

**Interface**
O ecrã controla `_loading`, `_position` e `_error`. Enquanto aguarda apresenta `CircularProgressIndicator`; em sucesso mostra latitude/longitude; em erro mostra uma mensagem.

**Mapa**
Constrói um URL `https://www.google.com/maps/search/?api=1&query=latitude,longitude` com `Uri.https` e chama `launchUrl`.

Código completo: `lib/services/location_service.dart` e `lib/screens/location_screen.dart`.

## Desafio 4 — API pública e FutureBuilder

**API**
GET `https://jsonplaceholder.typicode.com/photos?_limit=20`.

**Modelo**
`PhotoItem.fromJson` converte cada objeto JSON num modelo Dart tipado.

**Serviço**
`PhotoApi.fetchPhotos()` define timeout, verifica status HTTP, converte JSON e traduz falhas de comunicação em erros tratáveis.

**Estados**
`FutureBuilder` distingue waiting/loading, error, empty e sucesso. `RefreshIndicator` permite fazer pull-to-refresh; `AlwaysScrollableScrollPhysics` mantém o gesto disponível mesmo com poucos elementos.

Código completo: `lib/models/photo_item.dart`, `lib/services/photo_api.dart` e `lib/screens/photo_api_screen.dart`.

## Desafio 5 — API + favoritos persistentes

**Persistência**
A tabela `favorites` usa o identificador remoto da fotografia como chave primária e guarda título e URL da miniatura.

**Repository**
`FavoritesRepository` encapsula `insert`, `query`, `contains` e `delete`. As consultas por identificador usam `whereArgs`.

**Estado partilhado**
`FavoritesController extends ChangeNotifier` carrega a lista remota e os favoritos, expõe loading/error/dados e notifica a UI com `notifyListeners()`.

**UI**
O separador Explorar mostra os resultados da API; o separador Favoritos consulta SQLite. O ícone de coração adiciona ou remove um registo.

Código completo: `lib/data/app_database.dart`, `lib/repositories/favorites_repository.dart`, `lib/state/favorites_controller.dart` e `lib/screens/favorites_screen.dart`.
