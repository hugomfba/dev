# Task Manager — Arquitetura, estado e persistência

Projeto pedagógico Flutter/Dart para a aula de **Arquitetura, estado e persistência**. A aplicação final usa:

- UI em `screens/`;
- modelo `Task` em `models/`;
- persistência SQLite encapsulada em `data/`;
- Repository pattern em `repositories/`;
- gestão de estado assíncrono com Riverpod em `providers/`.

## Executar

1. Instale Flutter e configure um emulador Android ou dispositivo.
2. Abra esta pasta no VS Code.
3. No terminal, execute:

   ```bash
   flutter pub get
   flutter run
   ```

Se o seu ambiente Flutter/Dart for mais antigo e houver conflito de dependências, execute `flutter pub add flutter_riverpod sqflite path shared_preferences` para resolver versões compatíveis com o SDK instalado, e depois `flutter pub get`.

## Funcionalidades

- Criar, consultar, atualizar e eliminar tarefas;
- marcar como concluída;
- prioridade, importância e data limite;
- validação de formulário;
- confirmação por diálogo e ações num bottom sheet;
- feedback com SnackBar;
- persistência após fechar e reabrir a aplicação;
- estados de carregamento e erro.

Os dados ficam na base de dados local da aplicação. Não existe sincronização com servidor.

## Estrutura

```text
lib/
├── main.dart
├── models/task.dart
├── data/task_database.dart
├── repositories/task_repository.dart
├── providers/task_providers.dart
└── screens/
    ├── task_list_screen.dart
    ├── task_detail_screen.dart
    └── task_form_screen.dart
```

## Exemplos autónomos para os desafios

Em `examples/` encontram-se ficheiros de referência que representam soluções de desafios da apresentação:

- `challenge_1_memory_crud.dart`: CRUD em memória com `StatefulWidget`;
- `challenge_2_lifting_state.dart`: elevação do estado e callbacks;
- `challenge_3_repository_memory.dart`: Repository em memória, `Future.delayed`, `FutureBuilder` e tratamento de erros;
- `shared_preferences_settings.dart`: persistência de uma preferência simples.

Os ficheiros em `examples/` são exemplos autónomos. Para os executar, copie o conteúdo de um deles para `lib/main.dart` de um projeto Flutter. O exemplo de `shared_preferences` deve ser usado num projeto com esse pacote adicionado.

## Arquitetura da aplicação final

```text
TaskListScreen / TaskDetailScreen / TaskFormScreen
                         ↓
                  Riverpod Controller
                         ↓
                   TaskRepository
                         ↓
                   TaskDatabase
                         ↓
                       SQLite
```

## Limitações pedagógicas conhecidas

- Não há autenticação nem sincronização remota.
- O esquema SQLite começa na versão 1; alterações futuras ao modelo devem ser acompanhadas por uma migração de esquema.
- A aplicação mantém a implementação concentrada no mínimo necessário para ensinar separação de responsabilidades, não pretende ser uma arquitetura de produção completa.
