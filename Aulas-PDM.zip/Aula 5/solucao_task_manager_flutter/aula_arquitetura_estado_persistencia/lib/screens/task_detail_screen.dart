import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/task.dart';
import '../providers/task_providers.dart';
import 'task_form_screen.dart';

class TaskDetailScreen extends ConsumerWidget {
  final int taskId;
  const TaskDetailScreen({super.key, required this.taskId});

  Future<void> _edit(BuildContext context, WidgetRef ref, Task task) async {
    final updated = await Navigator.of(context).push<Task>(
      MaterialPageRoute(builder: (_) => TaskFormScreen(initialTask: task)),
    );
    if (!context.mounted || updated == null) return;
    await ref.read(tasksControllerProvider.notifier).updateTask(updated);
    if (!context.mounted) return;
    final result = ref.read(tasksControllerProvider);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(result.hasError
            ? 'Não foi possível atualizar a tarefa.'
            : 'Tarefa atualizada.'),
      ),
    );
  }

  Future<void> _delete(BuildContext context, WidgetRef ref, Task task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Eliminar tarefa?'),
        content: Text('Pretende eliminar "${task.title}"? Esta ação não pode ser anulada.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton.tonal(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
    if (!context.mounted || confirmed != true || task.id == null) return;

    final messenger = ScaffoldMessenger.of(context);
    await ref.read(tasksControllerProvider.notifier).deleteTask(task.id!);
    if (!context.mounted) return;
    final result = ref.read(tasksControllerProvider);
    if (result.hasError) {
      messenger.showSnackBar(const SnackBar(content: Text('Não foi possível eliminar a tarefa.')));
      return;
    }
    Navigator.of(context).pop();
    messenger.showSnackBar(const SnackBar(content: Text('Tarefa eliminada.')));
  }

  Future<void> _showActions(BuildContext context, WidgetRef ref, Task task) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Editar tarefa'),
              onTap: () => Navigator.pop(sheetContext, 'edit'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Eliminar tarefa'),
              onTap: () => Navigator.pop(sheetContext, 'delete'),
            ),
          ],
        ),
      ),
    );
    if (!context.mounted) return;
    if (action == 'edit') await _edit(context, ref, task);
    if (action == 'delete') await _delete(context, ref, task);
  }

  String _dateLabel(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasksAsync = ref.watch(tasksControllerProvider);
    return tasksAsync.when(
      loading: () => Scaffold(
        appBar: AppBar(title: const Text('Detalhe da tarefa')),
        body: const Center(child: CircularProgressIndicator()),
      ),
      error: (error, stack) => Scaffold(
        appBar: AppBar(title: const Text('Detalhe da tarefa')),
        body: Center(child: Text('Erro ao carregar: $error')),
      ),
      data: (tasks) {
        final matches = tasks.where((task) => task.id == taskId);
        if (matches.isEmpty) {
          return Scaffold(
            appBar: AppBar(title: const Text('Detalhe da tarefa')),
            body: const Center(child: Text('A tarefa já não existe.')),
          );
        }
        final task = matches.first;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Detalhe da tarefa'),
            actions: [
              IconButton(
                tooltip: 'Mais ações',
                onPressed: () => _showActions(context, ref, task),
                icon: const Icon(Icons.more_vert),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Icon(
                task.isCompleted ? Icons.task_alt : Icons.assignment_outlined,
                size: 72,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 20),
              Text(task.title, style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 12),
              Text(task.description.isEmpty ? 'Sem descrição.' : task.description),
              const SizedBox(height: 20),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.flag_outlined),
                      title: const Text('Prioridade'),
                      subtitle: Text(task.priority),
                    ),
                    ListTile(
                      leading: Icon(task.isImportant ? Icons.star : Icons.star_border),
                      title: const Text('Importante'),
                      subtitle: Text(task.isImportant ? 'Sim' : 'Não'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.event_outlined),
                      title: const Text('Data limite'),
                      subtitle: Text(task.dueDate == null ? 'Sem data' : _dateLabel(task.dueDate!)),
                    ),
                    ListTile(
                      leading: Icon(task.isCompleted ? Icons.check_circle : Icons.pending_actions),
                      title: const Text('Estado'),
                      subtitle: Text(task.isCompleted ? 'Concluída' : 'Pendente'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: () => ref.read(tasksControllerProvider.notifier).updateTask(
                      task.copyWith(isCompleted: !task.isCompleted),
                    ),
                icon: Icon(task.isCompleted ? Icons.undo : Icons.check_circle_outline),
                label: Text(task.isCompleted ? 'Marcar como pendente' : 'Marcar como concluída'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => _edit(context, ref, task),
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Editar tarefa'),
              ),
            ],
          ),
        );
      },
    );
  }
}
