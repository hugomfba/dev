import 'package:sqflite/sqflite.dart';
import '../data/task_database.dart';
import '../models/task.dart';

abstract interface class TaskRepository {
  Future<List<Task>> getAll();
  Future<int> insert(Task task);
  Future<int> update(Task task);
  Future<int> delete(int id);
}

class SqliteTaskRepository implements TaskRepository {
  SqliteTaskRepository(this._database);
  final TaskDatabase _database;

  @override
  Future<List<Task>> getAll() async {
    final Database db = await _database.database;
    final rows = await db.query(
      'tasks',
      orderBy: 'isCompleted ASC, isImportant DESC, id DESC',
    );
    return rows.map(Task.fromMap).toList(growable: false);
  }

  @override
  Future<int> insert(Task task) async {
    final db = await _database.database;
    return db.insert('tasks', task.toMap());
  }

  @override
  Future<int> update(Task task) async {
    final id = task.id;
    if (id == null) throw ArgumentError('A tarefa não tem identificador.');
    final db = await _database.database;
    return db.update(
      'tasks',
      task.toMap(),
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  @override
  Future<int> delete(int id) async {
    final db = await _database.database;
    return db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
}
