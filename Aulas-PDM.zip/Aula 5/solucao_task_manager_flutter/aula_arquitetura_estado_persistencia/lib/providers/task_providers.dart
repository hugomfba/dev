import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/task_database.dart';
import '../models/task.dart';
import '../repositories/task_repository.dart';

final taskRepositoryProvider = Provider<TaskRepository>((ref) {
  return SqliteTaskRepository(TaskDatabase.instance);
});

final tasksControllerProvider =
    AsyncNotifierProvider<TasksController, List<Task>>(TasksController.new);

class TasksController extends AsyncNotifier<List<Task>> {
  late TaskRepository _repository;

  @override
  Future<List<Task>> build() async {
    _repository = ref.watch(taskRepositoryProvider);
    return _repository.getAll();
  }

  Future<void> addTask(Task task) async {
    final repository = _repository;
    state = const AsyncLoading<List<Task>>();
    state = await AsyncValue.guard(() async {
      await repository.insert(task);
      return repository.getAll();
    });
  }

  Future<void> updateTask(Task task) async {
    final repository = _repository;
    state = const AsyncLoading<List<Task>>();
    state = await AsyncValue.guard(() async {
      await repository.update(task);
      return repository.getAll();
    });
  }

  Future<void> deleteTask(int id) async {
    final repository = _repository;
    state = const AsyncLoading<List<Task>>();
    state = await AsyncValue.guard(() async {
      await repository.delete(id);
      return repository.getAll();
    });
  }

  Future<void> refresh() async {
    final repository = _repository;
    state = const AsyncLoading<List<Task>>();
    state = await AsyncValue.guard(repository.getAll);
  }
}
