class Task {
  final int? id;
  final String title;
  final String description;
  final String priority;
  final bool isCompleted;
  final bool isImportant;
  final DateTime? dueDate;

  const Task({
    this.id,
    required this.title,
    this.description = '',
    this.priority = 'Média',
    this.isCompleted = false,
    this.isImportant = false,
    this.dueDate,
  });

  Task copyWith({
    int? id,
    String? title,
    String? description,
    String? priority,
    bool? isCompleted,
    bool? isImportant,
    DateTime? dueDate,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
      isImportant: isImportant ?? this.isImportant,
      dueDate: dueDate ?? this.dueDate,
    );
  }

  Map<String, Object?> toMap({bool includeId = false}) => {
        if (includeId && id != null) 'id': id,
        'title': title,
        'description': description,
        'priority': priority,
        'isCompleted': isCompleted ? 1 : 0,
        'isImportant': isImportant ? 1 : 0,
        'dueDate': dueDate?.toIso8601String(),
      };

  factory Task.fromMap(Map<String, Object?> map) {
    return Task(
      id: map['id'] as int?,
      title: map['title'] as String,
      description: map['description'] as String? ?? '',
      priority: map['priority'] as String? ?? 'Média',
      isCompleted: (map['isCompleted'] as int? ?? 0) == 1,
      isImportant: (map['isImportant'] as int? ?? 0) == 1,
      dueDate: map['dueDate'] == null
          ? null
          : DateTime.tryParse(map['dueDate'] as String),
    );
  }
}
