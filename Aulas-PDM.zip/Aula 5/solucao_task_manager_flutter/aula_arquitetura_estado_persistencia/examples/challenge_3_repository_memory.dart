import 'package:flutter/material.dart';

void main() => runApp(const RepositoryDemoApp());

class Student {
  const Student({required this.id, required this.name});
  final int id;
  final String name;
}

abstract interface class StudentRepository {
  Future<List<Student>> getAll();
  Future<void> add(String name);
}

class InMemoryStudentRepository implements StudentRepository {
  final List<Student> _items = [const Student(id: 1, name: 'Rita Silva')];
  int _nextId = 2;

  @override
  Future<List<Student>> getAll() async {
    await Future<void>.delayed(const Duration(milliseconds: 450));
    return List.unmodifiable(_items);
  }

  @override
  Future<void> add(String name) async {
    await Future<void>.delayed(const Duration(milliseconds: 300));
    if (name.trim().isEmpty) throw ArgumentError('O nome é obrigatório.');
    _items.add(Student(id: _nextId++, name: name.trim()));
  }
}

class RepositoryDemoApp extends StatelessWidget {
  const RepositoryDemoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple)),
        home: StudentsRepositoryPage(repository: InMemoryStudentRepository()),
      );
}

class StudentsRepositoryPage extends StatefulWidget {
  const StudentsRepositoryPage({super.key, required this.repository});
  final StudentRepository repository;
  @override
  State<StudentsRepositoryPage> createState() => _StudentsRepositoryPageState();
}

class _StudentsRepositoryPageState extends State<StudentsRepositoryPage> {
  late Future<List<Student>> _studentsFuture;
  final _controller = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _studentsFuture = widget.repository.getAll();
  }

  Future<void> _reload() async {
    setState(() => _studentsFuture = widget.repository.getAll());
  }

  Future<void> _add() async {
    setState(() => _saving = true);
    try {
      await widget.repository.add(_controller.text);
      _controller.clear();
      await _reload();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Estudante adicionado.')));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erro: $error')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Repository em memória')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Expanded(child: TextField(controller: _controller, decoration: const InputDecoration(labelText: 'Nome do estudante'))),
                const SizedBox(width: 8),
                IconButton(onPressed: _saving ? null : _add, icon: const Icon(Icons.add_circle)),
              ]),
            ),
            Expanded(
              child: FutureBuilder<List<Student>>(
                future: _studentsFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
                  if (snapshot.hasError) return Center(child: Text('Erro: ${snapshot.error}'));
                  final students = snapshot.data ?? [];
                  return ListView.builder(
                    itemCount: students.length,
                    itemBuilder: (context, index) => ListTile(title: Text(students[index].name), leading: const Icon(Icons.person_outline)),
                  );
                },
              ),
            ),
          ],
        ),
      );
}
