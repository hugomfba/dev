import 'package:flutter/material.dart';

void main() => runApp(const MemoryCrudApp());

class MemoryCrudApp extends StatelessWidget {
  const MemoryCrudApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal)),
        home: const MemoryCrudPage(),
      );
}

class Task {
  Task({required this.id, required this.title, this.done = false});
  final int id;
  String title;
  bool done;
}

class MemoryCrudPage extends StatefulWidget {
  const MemoryCrudPage({super.key});
  @override
  State<MemoryCrudPage> createState() => _MemoryCrudPageState();
}

class _MemoryCrudPageState extends State<MemoryCrudPage> {
  final List<Task> _tasks = [Task(id: 1, title: 'Estudar Dart')];
  int _nextId = 2;

  Future<void> _editTask([Task? task]) async {
    final controller = TextEditingController(text: task?.title ?? '');
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(task == null ? 'Nova tarefa' : 'Editar tarefa'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Título'),
          onSubmitted: (_) => Navigator.pop(dialogContext, controller.text.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('Guardar')),
        ],
      ),
    );
    controller.dispose();
    if (!mounted || title == null || title.trim().isEmpty) return;
    setState(() {
      if (task == null) {
        _tasks.add(Task(id: _nextId++, title: title.trim()));
      } else {
        task.title = title.trim();
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(task == null ? 'Tarefa criada.' : 'Tarefa atualizada.')),
    );
  }

  Future<void> _delete(Task task) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Eliminar?'),
        content: Text('Eliminar "${task.title}"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Eliminar')),
        ],
      ),
    );
    if (!mounted || yes != true) return;
    setState(() => _tasks.removeWhere((item) => item.id == task.id));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tarefa eliminada.')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CRUD em memória')),
        body: _tasks.isEmpty
            ? const Center(child: Text('Lista vazia — crie uma tarefa.'))
            : ListView.builder(
                itemCount: _tasks.length,
                itemBuilder: (context, index) {
                  final task = _tasks[index];
                  return Card(
                    child: ListTile(
                      leading: Checkbox(
                        value: task.done,
                        onChanged: (value) => setState(() => task.done = value ?? false),
                      ),
                      title: Text(task.title, style: TextStyle(decoration: task.done ? TextDecoration.lineThrough : null)),
                      onTap: () => _editTask(task),
                      trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _delete(task)),
                    ),
                  );
                },
              ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _editTask(),
          icon: const Icon(Icons.add),
          label: const Text('Nova tarefa'),
        ),
      );
}
