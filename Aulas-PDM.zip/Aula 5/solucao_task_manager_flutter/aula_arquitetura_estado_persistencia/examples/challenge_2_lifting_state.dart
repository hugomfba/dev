import 'package:flutter/material.dart';

void main() => runApp(const LiftingStateApp());

class LiftingStateApp extends StatelessWidget {
  const LiftingStateApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo)),
        home: const StudentsPage(),
      );
}

class Student {
  const Student(this.name, this.course);
  final String name;
  final String course;
}

class StudentsPage extends StatefulWidget {
  const StudentsPage({super.key});
  @override
  State<StudentsPage> createState() => _StudentsPageState();
}

class _StudentsPageState extends State<StudentsPage> {
  String _query = '';
  final _students = const [
    Student('Rita Silva', 'CTeSP de Sistemas de Informação'),
    Student('Tiago Costa', 'CTeSP de Tecnologias de Programação'),
    Student('Inês Martins', 'CTeSP de Sistemas de Informação'),
  ];

  @override
  Widget build(BuildContext context) {
    final visible = _students.where((s) => s.name.toLowerCase().contains(_query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Estudantes')),
      body: Column(
        children: [
          SearchBox(
            value: _query,
            onChanged: (value) => setState(() => _query = value),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: visible.length,
              itemBuilder: (context, index) {
                final student = visible[index];
                return StudentTile(
                  student: student,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Selecionado: ${student.name}')),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          builder: (_) => const SafeArea(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Folha inferior: ações relacionadas à lista.'),
            ),
          ),
        ),
        child: const Icon(Icons.more_horiz),
      ),
    );
  }
}

class SearchBox extends StatefulWidget {
  const SearchBox({super.key, required this.value, required this.onChanged});
  final String value;
  final ValueChanged<String> onChanged;

  @override
  State<SearchBox> createState() => _SearchBoxState();
}

class _SearchBoxState extends State<SearchBox> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.value);
  }

  @override
  void didUpdateWidget(covariant SearchBox oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value && _controller.text != widget.value) {
      _controller.value = TextEditingValue(
        text: widget.value,
        selection: TextSelection.collapsed(offset: widget.value.length),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: TextField(
          controller: _controller,
          decoration: const InputDecoration(labelText: 'Pesquisar estudante', prefixIcon: Icon(Icons.search)),
          onChanged: widget.onChanged,
        ),
      );
}

class StudentTile extends StatelessWidget {
  const StudentTile({super.key, required this.student, required this.onTap});
  final Student student;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 8),
        child: ListTile(
          leading: CircleAvatar(child: Text(student.name.characters.first)),
          title: Text(student.name),
          subtitle: Text(student.course),
          onTap: onTap,
        ),
      );
}
