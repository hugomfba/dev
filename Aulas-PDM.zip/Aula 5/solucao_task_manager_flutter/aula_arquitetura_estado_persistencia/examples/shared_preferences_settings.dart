// Exemplo isolado de preferência simples. Adicionar shared_preferences ao projeto.
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShowCompletedSetting extends StatefulWidget {
  const ShowCompletedSetting({super.key});
  @override
  State<ShowCompletedSetting> createState() => _ShowCompletedSettingState();
}

class _ShowCompletedSettingState extends State<ShowCompletedSetting> {
  static const _key = 'show_completed_tasks';
  bool _showCompleted = true;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPreference();
  }

  Future<void> _loadPreference() async {
    try {
      final preferences = SharedPreferencesAsync();
      final stored = await preferences.getBool(_key);
      if (!mounted) return;
      setState(() {
        _showCompleted = stored ?? true;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  Future<void> _savePreference(bool value) async {
    setState(() => _showCompleted = value);
    try {
      final preferences = SharedPreferencesAsync();
      await preferences.setBool(_key, value);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Não foi possível guardar a preferência: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return SwitchListTile(
      title: const Text('Mostrar tarefas concluídas'),
      value: _showCompleted,
      onChanged: _savePreference,
    );
  }
}
